package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.domain.EmployeeDetails;
import com.mindgate.main.domain.JobDescriptionDetails;
import com.mindgate.main.domain.LoginDetails;
import com.mindgate.main.repository.JobDescriptionDetailsRepositoryInterface;

@Service
public class JobDescriptionDetailsService implements JobDescriptionDetailsServiceInterface {

	@Autowired
	private JobDescriptionDetailsRepositoryInterface repositoryInterface;

	@Override
	public List<JobDescriptionDetails> getAllDescription() {

		return repositoryInterface.getAllDescription();
	}

	@Override
	public List<JobDescriptionDetails> getJobDescriptionByemployeeId(int employeeId) {

		return repositoryInterface.getJobDescriptionByemployeeId(employeeId);
	}

	@Override
	public boolean addJobDescription(JobDescriptionDetails jobDescriptionDetails) {
		return repositoryInterface.addJobDescription(jobDescriptionDetails);
	}

	@Override
	public List<JobDescriptionDetails> getJobDescriptionByProjectId(String projectId) {
		return repositoryInterface.getJobDescriptionByProjectId(projectId);
	}

	@Override
	public boolean updateJobStatus(JobDescriptionDetails jobDescriptionDetails) {
		
		return repositoryInterface.updateJobStatus(jobDescriptionDetails);
	}

	@Override
	public boolean updateRequiredCandidate(JobDescriptionDetails jobDescriptionDetails) {

		return repositoryInterface.updateRequiredCandidate(jobDescriptionDetails);
	}

	@Override
	public JobDescriptionDetails getJobDescriptionByJobId(int jobId) {
		// TODO Auto-generated method stub
		return repositoryInterface.getJobDescriptionByJobId(jobId);
	}

	@Override
	public List<JobDescriptionDetails> getAllDescriptionApproved() {
		System.out.println("getAllDescriptionApproved");
		return repositoryInterface.getAllDescriptionApproved();
	}

	@Override
	public List<JobDescriptionDetails> getAllDescriptionPublish() {
		System.out.println("in publish controller");
		return repositoryInterface.getAllDescriptionPublish();
	}

	
}
