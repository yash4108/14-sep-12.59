package com.mindgate.main.domain;

import java.util.Objects;

public class EmailMessage {

    private String to;
    private String subject;
    private String message;

    public EmailMessage() {
    }

    public EmailMessage(String to, String subject, String message) {
        this.to = to;
        this.subject = subject;
        this.message = message;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

	@Override
	public int hashCode() {
		return Objects.hash(message, subject, to);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmailMessage other = (EmailMessage) obj;
		return Objects.equals(message, other.message) && Objects.equals(subject, other.subject)
				&& Objects.equals(to, other.to);
	}

	@Override
	public String toString() {
		return "EmailMessage [to=" + to + ", subject=" + subject + ", message=" + message + "]";
	}
    
    
}
