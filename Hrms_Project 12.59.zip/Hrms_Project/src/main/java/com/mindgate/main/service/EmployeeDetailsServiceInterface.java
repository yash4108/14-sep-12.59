package com.mindgate.main.service;

import java.util.List;

import com.mindgate.main.domain.EmployeeDetails;

public interface EmployeeDetailsServiceInterface {

	public EmployeeDetails getEmployeeByLoginId(int loginId);

	public List<EmployeeDetails> checkEmployee(int jobId);
	
	public boolean updateJobStatus(EmployeeDetails employeeDetails);

	public boolean addEmployee(EmployeeDetails employeeDetails);
	
	public List<EmployeeDetails> getAllEmployee();
	
	public List<EmployeeDetails> checkInterviewer(int jobId);



}
