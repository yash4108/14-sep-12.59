package com.mindgate.main.service;

public interface EmailSenderServiceInterface {

	void sendEmail(String to, String subject, String message);

}
